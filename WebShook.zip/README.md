# WebShook
 Custom discord webhook spammer. You can spam however many messages you want to a webhook and also delete it.
 
![image](https://user-images.githubusercontent.com/77923481/122798876-15a19780-d28f-11eb-9458-727dfdb12955.png)

### Usage
- Provide the webhook url, username, message, and the number of messages (avatar url is not required)
- If you do more than 5 messages there will be a ratelimit cooldown.

### Examples
- Here is an example of spamming a webhook:

![2021-06-20 16-15-23_1](https://user-images.githubusercontent.com/77923481/122687224-4f1cc900-d1e3-11eb-9498-c769f4864fb2.gif)

- Here is an example of deleting a webhook:
![2021-06-20 16-15-23](https://user-images.githubusercontent.com/77923481/122687246-6b206a80-d1e3-11eb-9217-f939f9fddd13.gif)


### Donations
You can tip me Monero (XMR) if you'd like.
Here's my address:
```
44Bj8NnjEFydcxbJBD3CWSa8c2saTGjQJRVmRJrsbCWzdHYbjXCQ4e67MMrg18G9apU1Gze9T7mKggJJPt8mcRcf6Csvn11
```
